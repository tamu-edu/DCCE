# _Distinguishability of PCCE(Reviewer-A/B/D)._

We agree that PCCE can be distinguishable if the encoding is concatenated with the program counter (PC) of the point. DCCE targets clients that query the distinguishable encoding frequently at production runtime requiring minimum runtime overhead. Unlike calling-context for debugging, profile or offline optimization, our target clients require not only precise encoding but also fast operation to make the encoding distinguishable. 

Suppose clients employ PCCE's encoding with a concatenated PC. Every time clients query the distinguishable encoding, PCCE has to read the current PC and compare it with other PCs. In contrast, DCCE does not incur any extra operation to make the encoding distinguishable so it minimizes the runtime performance overhead.

Reviewer-D suggested to extend PCCE's algorithm to make distinguishable encoding by adding a dummy node connected from every other node. However, it still incurs extra operations because it has to find the edge weight from the current callsite to the dummy node.

Reviewer-A/B mentioned similarity of Ball-Larus path profiling but the BL algorithm does not allocate different IDs to paths from root node to non-leaf node whereas our target client queries calling-context at any node.

Reviewer-A commented to discuss related works such as probabilistic calling context(PCC). PCC generates a probabilistically unique value representing the current calling context using a sequence of callsites. We do not have in-depth comparison with PCC but we believe DCCE provides the same level of efficiency in terms of runtime overhead and the number of calling-contexts that each encoding scheme can cover without collision issue. The collision would be critical for some clients using the calling-context for security even with low conflit rate.

# _Evaluation method-Hashing inside getCCID() of PCCE(Reviewer-A/B/C/D)._
In the experiment, we want to show the overhead of PCCE and DCCE for target clients asking for distinguishable encoding. We add hash operation with the current function to getCCID function of PCCE to make it distinguishable and included getCCID function in our evaluation. Prior works did not consider the overhead of querying getCCID and not include it in their runtime overhead. However, it is significant overhead for the target clients.

We agree that hashing would be a naive approach to evaluate exact overhead of distinguishable PCCE. We plan to implement it using the same way PCCE suggested (concatenation of PC with the encoding).

For other clients that does not have the requirements such as distinguishable CCID, overhead of PCCE would be less than DCCE's overhead because it does not have to instrument every callsites to update the encoding. Figure 8 in the paper shows the runtime without getCCID for both PCCE and DCCE and PCCE is 1.03x faster than DCCE.

# _CCID Overflow(Reviewer-A/B/C/D)._
Like other encoding schemes such as PCCE and DrCCTProf, DCCE has a limitation in terms of CCID overflow. However, we do not thin that DCCE would incur CCID overflow with a benchmark that PCCE does not. Distinguishable PCCE needs an extra storage for PC but DCCE does not. If DCCE uses the same bits that the distinguishable PCCE uses (bits for the encoding plus bits for PC), the total number of calling-context each encoding can cover are the same. We plan to in-depth study and experiment for CCID overflow in a revision.

# _Related Work Section(Reviewer-A/C)_
We plan to discuss with other existing encoding schemes in a revision.

# _Responses to Reviewer-A_
## _Section 2.2 is confusing._
We agree that "the path from root to n" does not clearly define the calling context. We will revise it in the revision.

# _Responses to Reviewer-B_
## _Challenges from static analysis-Indirect call and Dynamically linked library_
We agree that analysis of jump targets of indirect call is well-known as challenging in static analysis. PCCE profiles the set of targets in many runs and Valence (Tong Zhou et al.) employes indirect call promotion supported by LLVM. As of now, we assign zero to the edge of indirect call. As we do not delete the instrumented code for zero weight edge, it would not affect the performance evaluation. However, it would affect the CCID overflow. We plan to apply the indirect call promotion to handle the indirect call in our experiment.

For dynamically linked libraries, DCCE can apply the algorithm to compute CCW at runtime instead of computing CCW statically. In other words, we can compute CCW at the current callsite and then update CCID. This is possible because the algorithm traverses the call graph DFS manner which is the same with the behavior of the function call mechanism.

## _The number of indirect calls in xalancbmk_
We use a LLVM-based SVF tool to draw call-graphs and identify indirect calls. The tool identified 136 indirect calls and 60 of them are reachable from the main function. We could not find the reference paper reporting it yet.

## _Only half of SPEC benchmarks are supported due to overflows or implementation issues_
Seven benchmarks are excluded due to CCID Overflow (500.perlbench_r, 502.gcc_r, 511.povray_r, 538.imagick_r, 600.perlbench_s, 602.gcc_s, 638.imagick_s). We have made more benchmarks available and they will be included in a revision.

## _Running both SPECspeed and SPECrate_
We will evaluate one version.

# _Responses to Reviewr-C_
## _Distinuishability in a cyclic-graph_
We consider a cycle in a call graph as the same context. For example, two calling-contents a->b->b and a->b have the same CCID.


## _Memory overhead_
DCCE-Static is not sensitive to the size of call graph because it allocates the integer variables for CCIDs (per-thread). 8-byte integer is required for CCID per thread.

DCCE-Dynamic is sensitive to the size of the call graph, especially the number of edges because it loads a pair of callsite-address and edge weight(s) from a CCW file. Table 3 shows the size of the CCW file and memory consumption. In rough estimation, two 8-byte integers are required for each callsite.

## _DCCE for Multi-threading_
For both DCCE-Static and DCCE-Dynamic, we create the thread-local variables for CCIDs per each thread and update CCID corresponding to the currently running thread. Therefore, each thread can query its own CCID.

## _Page 4, line-168:"the best calling context encoding for them"._
It means that the best calling-context encoding for them in terms of minimizing the performance overhead. We will clarify it in the revision.

## _Some notation in Algorithm-1 should be explained_
We will clarify Algorithm-1 to remind the definition of edge.

## _A standard proof environment._
We will polish the proof.

## _Are you assuming in Section-3.1 that the graph is acyclic and the extension to the cyclic case is in Section 3.4? If so, please state it explicitly._
Yes, we will state it explicitly.

# _Responses to Reviewer-D_

## _Contribution over DrCCTProf?_
We agree that DrCCTProf can be persistent across multiple execution runs using the actual calling-context rather than distinguishable CCID. However, using the calling-context itself (e.g., sequence of callsites) is not efficient for clients to analyze the program across multiple runs. In other words, DrCCTProf is not suitable to record calling-contexts with interesting events across multiple runs and analyze them all together. In multiple runs, DrCCTProf has to use calling-context rather than CCID and it will incur both space and performance overhead.

## _Comparison with DACCE_
We will discuss DACCE in more detail with citation in the revision.
